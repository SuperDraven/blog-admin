import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5cec3eea = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _7a049483 = () => interopDefault(import('../pages/article/create.vue' /* webpackChunkName: "pages/article/create" */))
const _be341a36 = () => interopDefault(import('../pages/article/list.vue' /* webpackChunkName: "pages/article/list" */))
const _0ecf1462 = () => interopDefault(import('../pages/category/create.vue' /* webpackChunkName: "pages/category/create" */))
const _6d59b731 = () => interopDefault(import('../pages/category/list.vue' /* webpackChunkName: "pages/category/list" */))
const _744438aa = () => interopDefault(import('../pages/error-page/403.vue' /* webpackChunkName: "pages/error-page/403" */))
const _7452502b = () => interopDefault(import('../pages/error-page/404.vue' /* webpackChunkName: "pages/error-page/404" */))
const _adffa530 = () => interopDefault(import('../pages/error-page/500.vue' /* webpackChunkName: "pages/error-page/500" */))
const _53867311 = () => interopDefault(import('../pages/error-page/error-page.vue' /* webpackChunkName: "pages/error-page/error-page" */))
const _6ddddbbb = () => interopDefault(import('../pages/form/article-publish.vue' /* webpackChunkName: "pages/form/article-publish" */))
const _5a371b4b = () => interopDefault(import('../pages/form/preview.vue' /* webpackChunkName: "pages/form/preview" */))
const _0ec2b3a6 = () => interopDefault(import('../pages/form/work-flow.vue' /* webpackChunkName: "pages/form/work-flow" */))
const _1cdc2576 = () => interopDefault(import('../pages/label/create.vue' /* webpackChunkName: "pages/label/create" */))
const _bbd2d7b2 = () => interopDefault(import('../pages/label/list.vue' /* webpackChunkName: "pages/label/list" */))
const _ff96904a = () => interopDefault(import('../pages/tables/dragable-table.vue' /* webpackChunkName: "pages/tables/dragable-table" */))
const _782fca31 = () => interopDefault(import('../pages/tables/editable-table.vue' /* webpackChunkName: "pages/tables/editable-table" */))
const _07e23d74 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
      path: "/login",
      component: _5cec3eea,
      name: "login"
    }, {
      path: "/article/create",
      component: _7a049483,
      name: "article-create"
    }, {
      path: "/article/list",
      component: _be341a36,
      name: "article-list"
    }, {
      path: "/category/create",
      component: _0ecf1462,
      name: "category-create"
    }, {
      path: "/category/list",
      component: _6d59b731,
      name: "category-list"
    }, {
      path: "/error-page/403",
      component: _744438aa,
      name: "error-page-403"
    }, {
      path: "/error-page/404",
      component: _7452502b,
      name: "error-page-404"
    }, {
      path: "/error-page/500",
      component: _adffa530,
      name: "error-page-500"
    }, {
      path: "/error-page/error-page",
      component: _53867311,
      name: "error-page-error-page"
    }, {
      path: "/form/article-publish",
      component: _6ddddbbb,
      name: "form-article-publish"
    }, {
      path: "/form/preview",
      component: _5a371b4b,
      name: "form-preview"
    }, {
      path: "/form/work-flow",
      component: _0ec2b3a6,
      name: "form-work-flow"
    }, {
      path: "/label/create",
      component: _1cdc2576,
      name: "label-create"
    }, {
      path: "/label/list",
      component: _bbd2d7b2,
      name: "label-list"
    }, {
      path: "/tables/dragable-table",
      component: _ff96904a,
      name: "tables-dragable-table"
    }, {
      path: "/tables/editable-table",
      component: _782fca31,
      name: "tables-editable-table"
    }, {
      path: "/",
      component: _07e23d74,
      name: "index"
    }],

  fallback: false
}

export function createRouter() {
  return new Router(routerOptions)
}
